"""
*common tools used throughout package*
"""
